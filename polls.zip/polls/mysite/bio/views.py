from django.shortcuts import HttpResponse
from django.shortcuts import render

from . models import Destination
# Create your views here.
def index(request):
    # dest1 = Destination()
    # dest1.name = 'Delhi'
    # dest1.dis = 'it is a land lock state and also a capital of india.'
    # dest1.price = 2223
    
    # dest2 = Destination()
    # dest2.name = 'Goa'
    # dest2.dis = 'margarita'
    # dest2.price = 4000

    # dest3 = Destination()
    # dest3.name = 'pune'
    # dest3.dis = 'chatrapati sivaji maharaj'
    # dest3.price = 5000

    # dests = [dest1,dest2,dest3]

    dests = Destination.objects.all()
     

    return render(request,'index.html',{'dests':dests})